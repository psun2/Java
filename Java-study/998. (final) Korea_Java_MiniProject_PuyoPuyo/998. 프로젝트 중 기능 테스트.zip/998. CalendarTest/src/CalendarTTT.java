import java.util.Date;

import javax.swing.JComboBox;

public class CalendarTTT {

	public static void main(String[] args) {

		Date today = new Date();

		System.out.println(today);

		JComboBox<>

	}

}
