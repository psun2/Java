import java.awt.Color;

import javax.swing.JFrame;

public class Second extends JFrame {

	public Second() {
		// TODO Auto-generated constructor stub

		setSize(500, 500);
		setLocationRelativeTo(null);
		setResizable(false);

		 setUndecorated(true);
		setBackground(new Color(255, 255, 255, 122));

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Second();
	}

}
