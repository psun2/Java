import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Test extends JFrame {

	public Test() {
		// TODO Auto-generated constructor stub
		setSize(500, 500);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(new BorderLayout());

//		JPanel p = new JPanel();
//		JLabel lb = new JLabel("��Ȱ��ȭ");
//		p.add(lb);
//
//		add(p, "Center");
//		 p.setBackground(Color.red);
//		 p.setBackground(new Color(255, 255, 255, 122));
//		 p.setOpaque(true);

		JPanel panel = new JPanel() { // ���� �������̵� �޾Ƽ� ... �׶��� �Լ��� �����Ѵ�...

			@Override
			public void paint(Graphics g) {
				super.paint(g);
				BufferedImage img = (BufferedImage) createImage(getWidth(), getHeight());
				Graphics2D g2 = (Graphics2D) g.create();
				g2.setComposite(AlphaComposite.SrcOver.derive(0.8f));
				g2.drawImage(img, 0, 0, null);
			}

		};

		JLabel lb = new JLabel("��Ȱ��ȭ");
		panel.add(lb);

		add(panel);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	}

	public static void main(String[] args) {
		new Test();
	}

}
