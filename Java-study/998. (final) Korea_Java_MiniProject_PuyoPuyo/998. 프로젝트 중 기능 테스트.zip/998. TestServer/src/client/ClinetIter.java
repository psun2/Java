package client;

import data.Data;

public interface ClinetIter {

	void receive(Data data);

}
