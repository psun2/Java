package mulGameTest;

// FIXME 2020-07-20 가끔씩 안터지는 버그
// TODO 2020-07-20  fix 완료 => 또 그런 현상 일어 날 수 있음

// FIXME 2020-07-20 PuyoFrame JLabel 중앙 정렬 안됨

// TODO 2020-07-20 PuyoTimer에서 최대속도를 15로 안잡아줌... 나름 괜찮아 보임.. 팀원과 상의후 결정