package test;

public class AAA {

	String name = "AAA";

	@Override
	public String toString() {
		return "AAA [name=" + name + "]";
	}

}
