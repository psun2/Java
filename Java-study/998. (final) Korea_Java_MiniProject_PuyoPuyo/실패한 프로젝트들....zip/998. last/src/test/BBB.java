package test;

public class BBB {

	AAA detail() {

		AAA result = new AAA();

		return result;

	}

}
