package jdbc_p;

public class GameRoomClear {

	public static void main(String[] args) {
		
		
		
		

	}

}
