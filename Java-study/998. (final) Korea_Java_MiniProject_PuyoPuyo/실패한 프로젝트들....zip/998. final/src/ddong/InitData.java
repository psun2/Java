package ddong;

public class InitData {

//	public static String ip = "192.168.100.42";
	public static String ip = "172.30.1.14";
//	public static String ip = "172.30.1.34";
	public static String id = "hr", pw = "hr";

}
