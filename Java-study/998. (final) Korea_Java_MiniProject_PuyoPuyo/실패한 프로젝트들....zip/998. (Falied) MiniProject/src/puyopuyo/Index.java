package puyopuyo;

public class Index {

	// 1. pyuoFrame => 전체적인 gui를 구성

	// 2. puyo class => 하나의 뿌요를 의미 Thread
	// => 터졌을때 재배치를 위하여 쓰레드를 사용

	// 2-1. y 축으로 내려갈때의 경우의수
	// => 뿌요가 내려가다가 바닥을 만난경우 (하)
	// => 뿌요가 내려가다가 다른 뿌요를 만난경우 (중)
	// => 뿌요가 터져서 빈공간이 생긴 경우 (상)

}
