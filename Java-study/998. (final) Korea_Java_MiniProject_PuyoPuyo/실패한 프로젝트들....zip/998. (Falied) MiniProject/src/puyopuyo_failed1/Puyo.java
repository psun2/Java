package puyopuyo_failed1;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Puyo extends JLabel {

	// 추후에 생성될때 이미지를 랜덤으로 받아서 사용 하면 됨.
	public Puyo() {
		// TODO Auto-generated constructor stub

		// ImageIcon icon = new ImageIcon(img);
		// setIcon(icon);

	}

}
