package game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class MapTest {

	public MapTest() {
		// TODO Auto-generated constructor stub

		ArrayList test = new ArrayList();

		System.out.println(test);

		System.out.println(548 % 50);
		System.out.println((548 % 50) % 50);

	}

}
