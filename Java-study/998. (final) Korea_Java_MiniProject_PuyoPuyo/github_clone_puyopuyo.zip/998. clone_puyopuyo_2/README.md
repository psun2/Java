[![QuickMVC](https://img.shields.io/badge/Quick%20MVC-Applied-magenta)](https://github.com/umjammer/umjammer/blob/wiki/QuickMVC.md)

# vavi-games-puyo

Puyopuyo clone for Java
