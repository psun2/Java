package fr.zimzim.casestate;

/**
 * 
 * @author Simon Jambu
 * "State" design pattern, used to represent the current state of a map case
 * @see Map
 * @see Case
 */
public interface CaseState {

}
