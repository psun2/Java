package an.tableBoard;


public class PaymentDB_DTO {
	String menu;
	String tableNum;
	Integer price;
	Integer count;
	Integer index;
}
