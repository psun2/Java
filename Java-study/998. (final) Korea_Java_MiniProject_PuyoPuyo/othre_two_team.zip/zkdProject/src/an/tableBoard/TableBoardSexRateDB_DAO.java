package an.tableBoard;

public class TableBoardSexRateDB_DAO {
	
	public TableBoardSexRateDB_DAO() {
		
	}
}
