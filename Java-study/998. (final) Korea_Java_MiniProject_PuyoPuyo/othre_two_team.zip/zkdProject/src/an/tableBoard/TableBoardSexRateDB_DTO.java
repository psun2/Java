package an.tableBoard;

public class TableBoardSexRateDB_DTO {

}
