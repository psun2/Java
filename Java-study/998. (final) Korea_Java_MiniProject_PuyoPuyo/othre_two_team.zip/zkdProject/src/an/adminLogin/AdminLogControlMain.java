package an.adminLogin;

public class AdminLogControlMain {

	public static void main(String[] args) {
		new an_adminLoginControl();
	}

}
