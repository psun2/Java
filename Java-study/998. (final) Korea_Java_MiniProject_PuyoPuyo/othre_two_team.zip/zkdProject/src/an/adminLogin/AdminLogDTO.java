package an.adminLogin;

import java.util.Vector;

public class AdminLogDTO extends Vector<AdminLogDTO>{
	String AD_PW, AD_NAME;


	public String getAD_PW() {
		return AD_PW;
	}

	public void setAD_PW(String aD_PW) {
		AD_PW = aD_PW;
	}

}
