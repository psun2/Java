package sup.bills;

public class BillsMain {

//	public static void main(String[] args) {
//		new BillsControl("table_1", "localhost");
//	}

}
