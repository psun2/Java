package hong.table.setting;

public class TableSetMessage {
	String order; //����, ����, ���� 
	String tableName; //���̺� �̸�
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
}
