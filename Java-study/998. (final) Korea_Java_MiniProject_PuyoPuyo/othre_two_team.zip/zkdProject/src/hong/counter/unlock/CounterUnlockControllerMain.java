package hong.counter.unlock;

public class CounterUnlockControllerMain {

	public static void main(String[] args) {
		new CounterUnlockController();
	}

}
