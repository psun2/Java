package hong;

public class InitData {
	public static String ip = "172.30.1.52";

}
