package hong.client;

import hong.server.MessageObject;

public interface ReceiverObjFromClient {
	public void getMsgObjectFromClient(MessageObject msgObject);
}
