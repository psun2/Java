package Robi;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import ddong.DDongData;


public class LoginTest extends JFrame {
	boolean login_chk = false;
	
	Container contentPane;
	JTextField idText;
	JPasswordField pwText;
	
	
	ArrayList<String> idstr;
	
	DDongData ddos;
	JLabel lbId;
	JLabel lbPw;
	JButton btnLogin;
	JButton btnJoin;
	JButton btnFindingInfo;
	JButton btnCloseGame;
	

	ObjectOutputStream oos;
	ObjectInputStream ois;
	
	boolean lochk;

	public LoginTest() {
		
		
		
		setTitle("회원가입");
		contentPane = getContentPane();
		setSize(455, 615);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		setResizable(false);
		
		
		lbId = new JLabel("Id");
		lbId.setBounds(69, 206, 74, 44);
		getContentPane().add(lbId);
		
		lbPw = new JLabel("Pw");
		lbPw.setBounds(69, 246, 74, 44);
		getContentPane().add(lbPw);
		
		//�α��� ��ư
		btnLogin = new JButton("Login");
		btnLogin.setBackground(Color.LIGHT_GRAY);
		btnLogin.setBounds(182, 297, 107, 29);
		getContentPane().add(btnLogin);
		btnLogin.addActionListener(actBut);
		
		//ȸ������ ��ư
		btnJoin = new JButton("회원가입");
		btnJoin.setBackground(Color.LIGHT_GRAY);
		btnJoin.setBounds(39, 337, 107, 19);
		getContentPane().add(btnJoin);
		btnJoin.addActionListener(actBut); 
		
		//���̵� ��� ã�� 
		btnFindingInfo = new JButton("계정 찾기");
		btnFindingInfo.setBackground(Color.LIGHT_GRAY);
		btnFindingInfo.setBounds(143, 337, 154, 19);
		getContentPane().add(btnFindingInfo);
		
		idText = new JTextField();
		idText.setBounds(160, 215, 166, 27);
		getContentPane().add(idText);
	
		idText.setColumns(10);
		
		pwText = new JPasswordField();
		pwText.setBounds(160, 255, 166, 27);
		getContentPane().add(pwText);
		btnFindingInfo.addActionListener(actBut);

		
		
		//���� ��ư ���� �� ����
		btnCloseGame = new JButton("나가기");
		btnCloseGame.setBackground(Color.LIGHT_GRAY);
		btnCloseGame.setBounds(295, 337, 107, 19);
		getContentPane().add(btnCloseGame);
		btnCloseGame.addActionListener(actBut);
		
		
			idstr = new ArrayList<String>();
		
			
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
	}
	
	Socket soc;
	ActionListener actBut = new ActionListener() {
	@Override
		public void actionPerformed(ActionEvent e) {
		
		
			if(e.getSource() == btnLogin) {
				try {
					soc = new Socket("192.168.0.25",7777);
					if(idText.getText()!=null || pwText.getText()!=null)
					{
						idstr.add(idText.getText());
						idstr.add(pwText.getText());
						
						new SenderLogin(soc).start();
						new ResiverLogin(soc).start();
						
						if(login_chk) {
							System.out.println("접속성공");
							new Lobby_Main();
							
						}
					
						
					}
					
					
					
				}catch (Exception e1) {
				
				}
		}
			
			if(e.getSource() == btnJoin) {
				new JoinTest();
		
			}
			
			if(e.getSource() == btnFindingInfo) {
				setVisible(false);
			}
			
			if(e.getSource() == btnCloseGame) {
				System.exit(0);
			}
		}
	};
	
	
	
//	
	public class SenderLogin extends Thread {
		public SenderLogin(Socket soc) {
		
			try {
				oos = new ObjectOutputStream(soc.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			
		}
		
		@Override
		public void run() {
			try {
				ddos = new DDongData();
				ddos.type ="login";
				ddos.data = idstr; 
				oos.writeObject(ddos);
				oos.flush();
				oos.reset();
				
				System.out.println("전송잘되요");
				System.out.println(ddos);
				System.out.println(idstr);
			} catch (Exception e) {
					
			}
			
			
		}
	}
	
	
	public class ResiverLogin extends Thread{
		public ResiverLogin(Socket soc) {
			
			try {
				ois = new ObjectInputStream(soc.getInputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Override
		public void run() {
	
			while(ois!=null) {
				try {
					DDongData data = (DDongData)ois.readObject();
					login_chk = (boolean)data.data;
					System.out.println(login_chk);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	
	
	public static void main(String[] args) {
		
		new LoginTest();

		
	}
	
	

}
