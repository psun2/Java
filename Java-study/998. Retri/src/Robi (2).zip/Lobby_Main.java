package Robi;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ddong.DDongData;
import jdbc_p.GameUserDTO;
import jdbc_p.LobbyDAO;
import jdbc_p.LobbyDTO;





public class Lobby_Main extends JFrame {
	ObjectOutputStream dos;
	ObjectInputStream ois;	
	ArrayList<String> arrad2;
	
	TreeSet<RoomBtn> btnList = new TreeSet<RoomBtn>(); 
	JFrame createPop;
	ArrayList<String> array;
	private JPanel contentPane;


	
	
	public Lobby_Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 50, 1130, 950);
		contentPane = new JPanel();
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		array = new ArrayList<String>();
		JPanel roomList = new JPanel();
		JScrollPane js = new JScrollPane(roomList);
		js.setBounds(30, 30, 780, 600);
//		roomList.setBackground(Color.BLUE);
		contentPane.add(js);
		

		JPanel userList = new UserList_Main();
		userList.setBounds(830, 30, 261, 600);
		userList.setBackground(Color.CYAN);
		contentPane.add(userList);
		// -- �������� ����Ʈ �� -------
		
		// -- ä��â -------
		JPanel chatArea = new ChatUser2();
		chatArea.setBounds(30, 640, 782, 228);
		chatArea.setBackground(Color.MAGENTA);
		contentPane.add(chatArea);
		// -- ä��â �� -------

		
		// -- �游��� ��ư -------`
		JButton createRoom = new JButton("방만들기");
		//createRoom.setFont(new Font("�޸յձ�������", Font.BOLD, 16));
//		createRoom.setBounds(969, 640, 122, 144);
		createRoom.setBounds(830, 640, 261, 144);
		createRoom.setBackground(Color.orange);
		contentPane.add(createRoom);
		
		createRoom.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				createPop = new JFrame();
				createPop.setBounds(600, 300, 390, 250);
				createPop.setTitle("방");
				createPop.add(new CreateRoomBtn_Main());
				createPop.setVisible(true);
			}
		});
		
		JButton rankBtn = new JButton("랭킹");
		//rankBtn.setFont(new Font("�޸յձ�������", Font.BOLD, 16));
		rankBtn.setBounds(830, 799, 261, 69);
		rankBtn.setBackground(Color.PINK);
		contentPane.add(rankBtn);
		
		rankBtn.addActionListener(new RankBtnAction());
		
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	
	}
	
	
	class RankBtnAction implements ActionListener{ // ��ŷ ��ư ������
		@Override
		public void actionPerformed(ActionEvent e) {
			
			JFrame rankPop = new JFrame();
			rankPop.setBounds(500, 75, 536, 700);
			rankPop.setTitle("랭킹");
			rankPop.add(new RankMain_GUI());
			rankPop.setVisible(true);
		}
	}

	
	
	
	//�߰� �κ� -----< ä�� ���� >----- 
	 class ChatUser2 extends JPanel {
			Socket socket; 
			JTextArea chatArea; 
			JTextField wrArea;

			int portN = 7777;
			String ipAdd = "192.168.0.25";



			public ChatUser2() { // ������
				try {
					setBounds(0, 0, 782, 228);
					setLayout(null);
					
					// chatArea - ��ȭâ
					chatArea = new JTextArea(); // ��ȭâ
					chatArea.setEnabled(false); // ��ȭ�� �ԷµǴ� �����̹Ƿ� �ؽ�Ʈ�� �Է����� ���ϰ� ���´�
					JScrollPane js = new JScrollPane(chatArea);
					js.setBounds(0, 0, 782, 188);
					chatArea.setBackground(new Color(250, 250, 250));
					//chatArea.setFont(new Font("�����ٸ����", Font.BOLD, 16));
					chatArea.setForeground(Color.black);
					add(js);
					// == ��ȭâ swing ==============
					
					// wrArea - �޼��� �Է�â
					wrArea = new JTextField();
					wrArea.setBounds(0, 188, 782, 40);
					//wrArea.setFont(new Font("�����ٸ����", Font.BOLD, 16));
					add(wrArea);
					// == �޼��� �Է�â swing ==============
					
					
					// ����
					socket = new Socket(ipAdd, portN); // ���Ͽ� ���� ip, port�ѹ� �ֱ�
					System.out.println("User socket start"); // ����ƴ��� Ȯ���� ���� ����

		
					
					wrArea.addActionListener(new ChatSender(socket));
					new ChatReciver(socket).start();
					
					// �޼��� �Է�â�� �޼����� �Է� �� ����ġ�� �Է��� ������ �������� �����ش�			
					// == ���� =================
					

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 

		
	class ChatSender implements ActionListener{

		ObjectOutputStream oos;
		public ChatSender(Socket socket) {

			try {

				oos = new ObjectOutputStream(socket.getOutputStream());
				
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		} // public ChatSender ��

		@Override
		public void actionPerformed(ActionEvent e) {
			
			try {
			
				DDongData sendDdong = new DDongData();
				sendDdong.type = "채팅";
				if(sendDdong.type.equals("채팅")) {
					sendDdong.data= wrArea.getText();
					oos.writeObject(sendDdong);
					oos.flush(); // 
					oos.reset(); // 
				}

				wrArea.setText(""); //
				wrArea.setFocusable(true); 
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}

	} // == class ChatSender �� =====================

	
	//�������� �����͸� ������ �˾ƾ� �Ұ�
	//�������´���, �������������� 

	
	public class ChatReciver extends Thread{
			ObjectInputStream ois;
			public ChatReciver(Socket socket) {
				try {
					ois = new ObjectInputStream(socket.getInputStream());
			
				} catch (IOException e) {} // try-catch ��
			} // == public ChatReciver �� =======

			@Override
			public void run() {
				try {
				while(ois!=null) { 
						try {
							
							
							DDongData data = (DDongData)ois.readObject();
							
							
							chatArea.append(data.data+"\n");
							chatArea.setCaretPosition(chatArea.getDocument().getLength());
							
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					
				
					} // while�� ��
				} catch (Exception e) {
					e.printStackTrace();
				} // try-catch ��
			} // == public void run() �� =======
			
		} // == class ChatReciver =====================
	
	 }
	 


	public static void main(String[] args) {

		new Lobby_Main();
	}
}
