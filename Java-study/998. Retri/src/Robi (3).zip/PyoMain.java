package Robi;

public class PyoMain {
	LoginTest lo;

	
	public PyoMain() {

	}
	public static void main(String[] args) {
		
		
		new PyoMain();
	}
}
