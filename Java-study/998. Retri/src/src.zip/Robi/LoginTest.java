package Robi;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JTextField;

import jdbc_p.GameUserDAO;
import jdbc_p.GameUserDTO;
import jdbc_p.LobbyDAO;
import jdbc_p.LobbyDTO;

import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class LoginTest extends JFrame {
	GameUserDTO dto = new GameUserDTO();
	GameUserDAO dao = new GameUserDAO();
	boolean login_chk = false;
	
	Container contentPane;
	JTextField idText;
	JPasswordField pwText;
	JLabel lbId;
	JLabel lbPw;
	JButton btnLogin;
	JButton btnJoin;
	JButton btnFindingInfo;
	JButton btnCloseGame;

	public LoginTest() {
		
		//�α��� frame ����
		setTitle("��������");
		contentPane = getContentPane();
		setSize(455, 615);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		setResizable(false);
		
		
		lbId = new JLabel("���̵�");
		lbId.setBounds(69, 206, 74, 44);
		getContentPane().add(lbId);
		
		lbPw = new JLabel("��й�ȣ");
		lbPw.setBounds(69, 246, 74, 44);
		getContentPane().add(lbPw);
		
		//�α��� ��ư
		btnLogin = new JButton("�α���");
		btnLogin.setBackground(Color.LIGHT_GRAY);
		btnLogin.setBounds(182, 297, 107, 29);
		getContentPane().add(btnLogin);
		btnLogin.addActionListener(actBut);
		
		//ȸ������ ��ư
		btnJoin = new JButton("ȸ������");
		btnJoin.setBackground(Color.LIGHT_GRAY);
		btnJoin.setBounds(39, 337, 107, 19);
		getContentPane().add(btnJoin);
		btnJoin.addActionListener(actBut); 
		
		//���̵� ��� ã�� 
		btnFindingInfo = new JButton("���̵�/��й�ȣã��");
		btnFindingInfo.setBackground(Color.LIGHT_GRAY);
		btnFindingInfo.setBounds(143, 337, 154, 19);
		getContentPane().add(btnFindingInfo);
		
		idText = new JTextField();
		idText.setBounds(160, 215, 166, 27);
		getContentPane().add(idText);
	
		idText.setColumns(10);
		
		pwText = new JPasswordField();
		pwText.setBounds(160, 255, 166, 27);
		getContentPane().add(pwText);
		btnFindingInfo.addActionListener(actBut);

		
		
		//���� ��ư ���� �� ����
		btnCloseGame = new JButton("����");
		btnCloseGame.setBackground(Color.LIGHT_GRAY);
		btnCloseGame.setBounds(295, 337, 107, 19);
		getContentPane().add(btnCloseGame);
		btnCloseGame.addActionListener(actBut);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
	}
	
	
	ActionListener actBut = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == btnLogin) {
				if(dao.Login(idText.getText(), pwText.getText())==true)
				{
					login_chk = true;
					setVisible(false);
					//JOptionPane.showMessageDialog(null, "�α��� ����");
				
					  new Lobby_Main();
					  LobbyDTO dto = new LobbyDTO();
		              dto.setId(idText.getText());
		              new LobbyDAO().insert(dto);
					
				}
				
				if(dao.Login(idText.getText(), pwText.getText())==false)
					
				JOptionPane.showMessageDialog(null, "���̵�� ��й�ȣ Ȯ�����ּ���");
			}
			
			if(e.getSource() == btnJoin) {
				new JoinTest();
		
			}
			
			if(e.getSource() == btnFindingInfo) {
				setVisible(false);
			}
			
			if(e.getSource() == btnCloseGame) {
				System.exit(0);
			}
		}
	};
	
	
	public static void main(String[] args) {
		
		new LoginTest();

		
	}
	
	

}
