package ddong;

public class InitData {
	
	public static String ip = "172.30.1.14";
	
	public static String id = "hr", pw = "hr";

}
