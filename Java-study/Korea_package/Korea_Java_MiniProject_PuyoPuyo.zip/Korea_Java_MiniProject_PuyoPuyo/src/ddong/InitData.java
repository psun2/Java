package ddong;

public class InitData {

	public static String ip = "192.168.1.9";

	public static String id = "hr", pw = "hr";

}
