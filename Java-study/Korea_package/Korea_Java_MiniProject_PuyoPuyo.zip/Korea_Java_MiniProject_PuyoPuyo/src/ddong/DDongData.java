package ddong;

import java.io.Serializable;
import java.util.ArrayList;

public class DDongData implements Serializable {
   
   private static final long serialVersionUID = 1000L;
   
  
   public String src, type;
   
   public String dst;
   
   public Object data;
   
   public boolean chk;
   
   

}