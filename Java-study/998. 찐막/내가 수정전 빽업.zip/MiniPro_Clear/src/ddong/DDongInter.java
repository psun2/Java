package ddong;

public interface DDongInter {
	
	void reciver(DDongData dd);

}
