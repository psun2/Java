package com.lec.mvc_refactoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcRefactoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcRefactoringApplication.class, args);
	}

}
