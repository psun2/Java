package com.lec.mvc_refactoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcRefactoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
