package com.lec.interceptortestmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterceptortestmavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterceptortestmavenApplication.class, args);
	}

}
