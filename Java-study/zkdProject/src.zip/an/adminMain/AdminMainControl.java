package an.adminMain;

import java.awt.EventQueue;

import javax.swing.JOptionPane;

import hong.client.DefaultClient;
import hong.client.ReceiverObjFromClient;
import hong.server.MessageObject;

public class AdminMainControl {
	AdminMainView adminView;
	Receiver receiver;
//	String ip;
//	int port;
	public AdminMainControl() {
		
		adminView = new AdminMainView(this);
		receiver = new Receiver();
	}
	class Receiver implements ReceiverObjFromClient{
		DefaultClient client;
		public Receiver() {
			super();
			this.client = new DefaultClient("ī����", this, "localhost", 7777);
		}
		@Override
		public void getMsgObjectFromClient(MessageObject msgObject) {
			
			switch (msgObject.getType()) {
			case "�����Ϸ�": 
				adminView.tbc.completeOrder(msgObject);
				break;
			case "ȣ��" :
				
				break;
			
			}
			System.out.println(msgObject.getMessageMain());
			
		} //���� �޾Ƽ� �ڹٷ� �����͸� �̾� �� ������,
		
	}
	
	
}

