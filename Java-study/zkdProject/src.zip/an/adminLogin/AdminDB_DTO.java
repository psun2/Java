package an.adminLogin;

public class AdminDB_DTO {

	Integer password;


	public int getPassword() {
		return password;
	}


	public void setPassword(int password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return ""+ password;
	}
	
	
	

}
