package an.adminLogin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import an.adminSettings.AdminSettingsControl;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class AdminLoginView extends JFrame implements ActionListener {

	ArrayList<AdminDB_DTO> admin;
	
	
	
	JPanel contentPane;
	JPasswordField password;
	JLabel result;
	String passwordnumber = "1111"; //��й�ȣ �ʱⰪ
	String strPw = "";
	
	
	AdminLoginControl control; // �α��� ��Ʈ�� Ŭ����.
	
//	an_adminSettingsControl settingscontrol;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLoginView frame = new AdminLoginView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLoginView() {
		
		admin = new AdminDB_DAO().list();
		for (AdminDB_DTO adminpassword : admin) {
			//��й�ȣ 123�� ��µȴ� 
			
			
			strPw += adminpassword;
			
		}
		
		System.out.println(strPw); //strPw ���� ���� ���ڰ� ��й�ȣ�� ������ִ�.
		
		
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		control =  new AdminLoginControl(this); // �����ڸ� ������Ѵ�.
		setBounds(500, 200, 869, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.WEST);
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("User :");
		panel_2.add(lblNewLabel);
		
		password = new JPasswordField(10);
		panel_2.add(password);
		
		JButton btnNewButton = new JButton("�α���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				strPw = String.valueOf(password.getPassword());
				if(strPw.equals(passwordnumber)) {
					result.setText("�α����� �Ǿ����ϴ�");
					result.setForeground(Color.blue);
					
				 control.loginViewClose();
				 
				 
				}else {
					result.setText("��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
					result.setForeground(Color.RED);
				}
				//strPw += nps ���� �Ǵ� ���̴�.
				//strPw ���� 1��������  if���� ������ ps == strPw ����ϸ���? nps <--�� ��й�ȣ �Է� ���� �ְ�
				
			}
		});
		panel_2.add(btnNewButton);
		
		result = new JLabel(" ");
		panel_2.add(result);
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	

}

