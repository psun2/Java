package an.adminLogin;

import javax.swing.JFrame;

import an.adminMain.AdminMainControl;
import an.adminMain.AdminMainView;

public class AdminLoginControl{
	
	AdminLoginView loginview;  // �α��� �� �ҷ�����.
	AdminMainControl adminControl;
	 
	public AdminLoginControl(AdminLoginView loginView) {
		this.loginview = loginView;
	}

	public void loginViewClose() {
		
		//loginview.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loginview.dispose();
		adminControl = new AdminMainControl();
	}
	
}


