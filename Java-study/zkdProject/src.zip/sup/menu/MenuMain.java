package sup.menu;

public class MenuMain {

	public static void main(String[] args) {
//		new MenuMainController("table_1","localhost", 7777);
	}

}
