package sup.menuManagement;

public class MM_main {

	public static void main(String[] args) {
		new MMcontroller("localhost", 7777);
	}

}
