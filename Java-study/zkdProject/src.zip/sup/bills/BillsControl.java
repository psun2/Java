package sup.bills;

import java.util.ArrayList;

import javax.swing.JPanel;

import sup.menu.OrderListDBControl;
import sup.menu.OrderMenu;

public class BillsControl {
	BillsView billsMain;
	Bills bills;
	ArrayList<OrderedMenusLable> orderedMenus;
	String ip;
	String tableNum;
	public BillsControl(String tableNum, String ip) {
		this.tableNum = tableNum;
		this.ip=ip;
		bills = new Bills();
		bills.orderMenus =  new OrderListDBControl(ip).list(tableNum);
		billsMain = new BillsView(this);
		
		addOrderList();
		bills.sum();
		setTot();
	}
	void cancelOrder(OrderMenu orderMenu) {
		int i = 0;
		for (OrderMenu om : bills.orderMenus) {
			if(orderMenu==om && orderMenu.getCancel()==1) {
				new OrderListDBControl(ip).del_menu(om);
				bills.orderMenus.remove(i);
				billsMain.panel_2.remove(i);
				break;
			}
			i++;
		}
		billsMain.panel_2.setVisible(false);
		billsMain.panel_2.setVisible(true);
		
	}
	void setTot() {
		billsMain.totLable.setText(bills.sumPrice+"");
	}
	void addOrderList() {
		orderedMenus = new ArrayList<OrderedMenusLable>();
		for (OrderMenu orderMenu : bills.orderMenus) {
			System.out.println(orderMenu);
			OrderedMenusLable orderedMenusLable = new OrderedMenusLable(billsMain,orderMenu);
			orderedMenus.add(orderedMenusLable);
		}
	}
	
	void receiveMessage(Object orderState) {
//		bills.orderMenus = new OrderListDBControl(ip).list(tableNum);
		OrderMenu om1 = new OrderListDBControl(ip).detail(orderState, tableNum);
		changeOrderMenu(om1);
		changeOrderMenuLable(om1);
		
	}
	void changeOrderMenu(OrderMenu om1) {
		int i = 0;
		for (OrderMenu oms : bills.orderMenus) {
			if(om1.getMenuName().equals(oms.getMenuName())&&om1.getTimestamp().equals(oms.getTimestamp())) {
				bills.orderMenus.set(i, om1);
			}
			i++;
		}
	}
	void changeOrderMenuLable(OrderMenu om1) {
		int i = 0;
		
		for (OrderMenu oms : bills.orderMenus) {
			if(om1.getMenuName().equals(oms.getMenuName())&&om1.getTimestamp().equals(oms.getTimestamp())) {
				OrderedMenusLable oml = orderedMenus.get(i);
				oml.menuState.setText(om1.getState());
				orderedMenus.set(i, oml);
			}
			i++;
		}
	}
	public static void main(String[] args) {
//		new BillsControl();
	}

}
