package hong.table;

public class TableMainControllerMain {

	public static void main(String[] args) {
		new TableMainController("���̺�_2");
	}
}
